/**
 * 
 */
package com.vst.java.training.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.vst.java.training.comman.JDBC;
import com.vst.java.training.comman.QueryMaker;

/**
 * @author SACHIN GURJAR
 * 
 */
public class NameHelper {

	/*
	 * Creating Logger object, logger object mapped with NameHelper class for
	 * writing Loggers.
	 */
	private static final Logger logger = Logger.getLogger(NameHelper.class);

	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	

	public String getDesignationName(String id) {
		String name = null;
		String query = QueryMaker.GET_DESIGNATION_NAME;
		try {
			connection = JDBC.getCon();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				name = resultSet.getString("DES_NAME");
				if (name==null) {
					name = resultSet.getString("");
				} else {
					name = resultSet.getString("DES_NAME");
				}
			}
		} catch (SQLException sqlException) {
			System.out.println(sqlException);
			logger.error("Connection Fail , " + sqlException);
		} catch (Exception exception) {
			System.out.println(exception);
			logger.error("Connection Fail , " + exception);
		}
		return name;
	}

}
