/**
 * 
 */
package com.vst.java.training.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.vst.java.training.comman.JDBC;
import com.vst.java.training.comman.QueryMaker;

/**
 * @author SACHIN GURJAR
 *
 */
public class ListHelper {
	
	/*
	 * Creating Logger object, logger object mapped with ListHelper class
	 * for writing Loggers.
	 */
	private static final Logger logger = Logger
			.getLogger(ListHelper.class);
	
	Connection connection=null;
	PreparedStatement preparedStatement=null;
	ResultSet resultSet=null;

	
	/**
	 * <p><code>HashMap<Integer, String> getDesignationList()</code> This method
	 * to return designation list.</p>
	 * @return list
	 */
	
	public HashMap<Integer, String> getDesignationList() {
		int id;
		String name;
		HashMap<Integer, String> list=new HashMap<Integer, String>();
		
		try {
			connection=JDBC.getCon();
			preparedStatement=connection.prepareStatement(QueryMaker.GET_DESIGNATION_LIST);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				id=resultSet.getInt(1);
				name=resultSet.getString(2);
				list.put(id, name);
			}
		}catch (SQLException sqlException) {
			System.out.println(sqlException);
			logger.error("Connection Fail , " + sqlException);
		} catch (Exception exception) {
			System.out.println(exception);
			logger.error("Connection Fail , " + exception);
		}
		
		return list;
	}

}
